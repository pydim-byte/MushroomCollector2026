import pygame

class SpriteSheet:
    def __init__(self, sheet, frames, width, height):
        self.sprites = []
        self.sheet = pygame.image.load(sheet).convert_alpha()
        self.frames = frames
        self.width = width
        self.height = height
        self.get_sprites()


    def get_sprites(self):
        for f in range(self.frames):
            self.sprites.append(self.sheet.subsurface(
                pygame.Rect((f*self.width, 0), (self.width, self.height))
            ))
        return  self.sprites