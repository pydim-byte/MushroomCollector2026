import asyncio

import os
import sys
import pygame


from utils.player import Player
from utils.slime import Slime
from utils.boss_slime import Boss_slime
from utils.tilemap import TileMap

level_tilestet = os.path.join('assets', 'tilemaps', 'TileJump.tmx')


class Camera:
    def __init__(self,min,max):
        self.offset = pygame.Vector2(0,0)
        self.min = min
        self.max = max

    def get_offset(self,player):
        self.offset.x = player.rect.centerx - 160
        self.offset.x = max(self.min,(min(self.offset.x,self.max)))


async def play():
    pygame.init()
    pygame.mixer.music.load(os.path.join('assets', 'audio','berlin.ogg')) 
    pygame.mixer.music.set_volume(0.2)
    pygame.mixer.music.play(-1)
    display = pygame.display.set_mode((640, 360))
    screen = pygame.Surface((320, 180))
    clock = pygame.time.Clock()
    fps = 60

    player = Player()
    slime = Slime()
    boss = Boss_slime()
    level = TileMap(level_tilestet)
    camera = Camera(0,952)

    heart = pygame.image.load(os.path.join('assets','sprites','heart.png'))
    heart_width = heart.get_width()

    game_over = pygame.image.load(os.path.join('assets','menus','game_over.png'))
    door_entered = False
    victory = pygame.image.load(os.path.join('assets','menus','victory.png'))

    while True:
        await asyncio.sleep(0)
        screen.fill((0, 0, 0))
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

        inputs = pygame.key.get_pressed()

        player.handle_inputs(inputs)

        if player.alive:
            player.update(level.platforms,slime,boss,camera.offset)

        if slime.alive:
            slime.update(level.platforms,player)

        if player.rect.x >= 952:
            level.platforms.append(level.boss_wall)
            camera.min = camera.offset.x
            if camera.min < 952:
                camera.min += 1

        camera.get_offset(player)

        for sprite in level.map_sprites:
            screen.blit(sprite.image,(sprite.rect.x - camera.offset.x, sprite.rect.y))

        if slime.alive:
            slime.draw(screen,camera.offset)

        if boss.alive:
            boss.update(level.platforms,player)
            boss.draw(screen,camera.offset)

        for i in range(player.hp):
            screen.blit(heart,(4 + i * (heart_width+4),4))

        if not boss.alive:
            pygame.draw.rect(screen,(255,255,255),(1212-camera.offset.x,132,16,28))
            if player.rect.colliderect(pygame.Rect((1212,132,16,28))):
                door_entered = True

        if door_entered:
            screen.blit(victory,(0,0))
            if inputs[pygame.K_SPACE]:
                door_entered = False
                player = Player()
                slime = Slime()
                boss = Boss_slime()
                level = TileMap(level_tilestet)
                camera = Camera(0,952)

        if player.alive:
            player.draw(screen,camera.offset)

        if player.rect.y >= 250:
            player.hp = 0

        if player.hp <= 0:
            screen.blit(game_over,(0,0))

        if player.hp <=0:
            if inputs[pygame.K_SPACE]:
                player = Player()
                slime = Slime()
                boss = Boss_slime()
                level = TileMap(level_tilestet)
                camera = Camera(0,952)

        display.blit(pygame.transform.scale(
            screen, display.get_rect().size), (0,0))
        pygame.display.flip()
        clock.tick(fps)


asyncio.run(play())
